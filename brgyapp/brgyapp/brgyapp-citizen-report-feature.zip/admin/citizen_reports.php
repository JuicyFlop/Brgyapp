<?php
declare(strict_types=1);

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once __DIR__ . "/../config/database.php";

$success = "";
$error = "";

/*
|--------------------------------------------------------------------------
| UPDATE STATUS / NOTES
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_report"])) {
    $id = (int)($_POST["id"] ?? 0);
    $status = $_POST["status"] ?? "Pending";
    $adminNotes = trim($_POST["admin_notes"] ?? "");

    $allowedStatuses = [
        "Pending", "Verified", "Responding", "Resolved", "Rejected"
    ];

    if ($id <= 0 || !in_array($status, $allowedStatuses, true)) {
        $error = "Invalid report update.";
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE citizen_reports
                SET status = :status,
                    admin_notes = :admin_notes
                WHERE id = :id
            ");

            $stmt->execute([
                ":status" => $status,
                ":admin_notes" => $adminNotes !== "" ? $adminNotes : null,
                ":id" => $id
            ]);

            $success = "Citizen report updated successfully.";
        } catch (PDOException $e) {
            $error = "Unable to update the citizen report.";
        }
    }
}

/*
|--------------------------------------------------------------------------
| CONVERT CITIZEN REPORT TO OFFICIAL INCIDENT
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["create_incident"])) {
    $id = (int)($_POST["id"] ?? 0);

    try {
        $stmt = $pdo->prepare("
            SELECT *
            FROM citizen_reports
            WHERE id = :id
            LIMIT 1
        ");
        $stmt->execute([":id" => $id]);
        $report = $stmt->fetch();

        if (!$report) {
            throw new RuntimeException("Report not found.");
        }

        if (!empty($report["incident_id"])) {
            throw new RuntimeException("This report has already been converted to an incident.");
        }

        $location = "GPS: " . $report["latitude"] . ", " . $report["longitude"];

        $stmt = $pdo->prepare("
            INSERT INTO incidents (
                incident_type,
                description,
                location,
                reported_by,
                status,
                incident_date
            ) VALUES (
                :incident_type,
                :description,
                :location,
                :reported_by,
                'Reported',
                :incident_date
            )
        ");

        $stmt->execute([
            ":incident_type" => $report["incident_type"],
            ":description" => $report["description"],
            ":location" => $location,
            ":reported_by" => "Citizen Report " . $report["report_code"],
            ":incident_date" => $report["created_at"]
        ]);

        $incidentId = (int)$pdo->lastInsertId();

        $stmt = $pdo->prepare("
            UPDATE citizen_reports
            SET incident_id = :incident_id,
                status = 'Verified'
            WHERE id = :id
        ");

        $stmt->execute([
            ":incident_id" => $incidentId,
            ":id" => $id
        ]);

        $success = "Citizen report converted to official incident #" . $incidentId . ".";
    } catch (Throwable $e) {
        $error = "Unable to create official incident: " . $e->getMessage();
    }
}

$statusFilter = $_GET["status"] ?? "";
$search = trim($_GET["search"] ?? "");

$sql = "
    SELECT *
    FROM citizen_reports
    WHERE 1=1
";
$params = [];

if (in_array($statusFilter, ["Pending","Verified","Responding","Resolved","Rejected"], true)) {
    $sql .= " AND status = :status";
    $params[":status"] = $statusFilter;
}

if ($search !== "") {
    $sql .= "
        AND (
            report_code LIKE :search
            OR incident_type LIKE :search
            OR description LIKE :search
            OR reporter_name LIKE :search
        )
    ";
    $params[":search"] = "%" . $search . "%";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

$pendingCount = (int)$pdo->query("
    SELECT COUNT(*)
    FROM citizen_reports
    WHERE status = 'Pending'
")->fetchColumn();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Citizen Reports | Barangay DMS</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
    <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        crossorigin=""
    >

    <style>
        #reportMap { height: 300px; border-radius: 10px; }
        .report-photo {
            width: 90px;
            height: 70px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <a href="dashboard.php" class="navbar-brand fw-bold">
            Barangay Disaster Management System
        </a>
        <div class="text-white">
            <?= htmlspecialchars($_SESSION["full_name"] ?? "") ?>
            |
            <a href="../auth/logout.php" class="text-white text-decoration-none">Logout</a>
        </div>
    </div>
</nav>

<div class="container-fluid">
    <div class="row">

        <aside class="col-md-2 bg-dark min-vh-100 p-3">
            <h5 class="text-white mb-4">BDMS Menu</h5>
            <div class="nav flex-column">
                <a href="dashboard.php" class="nav-link text-white">Dashboard</a>
                <a href="residents.php" class="nav-link text-white">Residents</a>
                <a href="households.php" class="nav-link text-white">Households</a>
                <a href="incidents.php" class="nav-link text-white">Disaster Incidents</a>
                <a href="evacuees.php" class="nav-link text-white">Evacuees</a>
                <a href="resources.php" class="nav-link text-white">Resources</a>
                <a href="announcements.php" class="nav-link text-white">Announcements</a>
                <a href="reports.php" class="nav-link text-white">Reports</a>
                <a href="citizen_reports.php"
                   class="nav-link text-white bg-danger rounded mt-2">
                    Citizen Reports
                    <?php if ($pendingCount > 0): ?>
                        <span class="badge bg-warning text-dark float-end"><?= $pendingCount ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </aside>

        <main class="col-md-10 p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="fw-bold mb-1">Citizen Emergency Reports</h2>
                    <p class="text-muted mb-0">
                        Review photos, descriptions, GPS coordinates, and report status.
                    </p>
                </div>
                <a href="../report.php" target="_blank" class="btn btn-danger">
                    Open Citizen Report Page
                </a>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <form class="row g-2">
                        <div class="col-md-5">
                            <input
                                type="search"
                                name="search"
                                value="<?= htmlspecialchars($search) ?>"
                                class="form-control"
                                placeholder="Search report, type, description..."
                            >
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-select">
                                <option value="">All Statuses</option>
                                <?php foreach (["Pending","Verified","Responding","Resolved","Rejected"] as $status): ?>
                                    <option value="<?= $status ?>" <?= $statusFilter === $status ? "selected" : "" ?>>
                                        <?= $status ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-primary w-100">Filter</button>
                        </div>
                        <div class="col-md-2">
                            <a href="citizen_reports.php" class="btn btn-outline-secondary w-100">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-body">

                    <?php if (!$reports): ?>
                        <div class="text-center text-muted py-5">
                            No citizen reports found.
                        </div>
                    <?php else: ?>

                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                            <tr>
                                <th>Report</th>
                                <th>Photo</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Submitted</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php foreach ($reports as $report): ?>
                                <?php
                                    $badge = match ($report["status"]) {
                                        "Pending" => "bg-warning text-dark",
                                        "Verified" => "bg-info text-dark",
                                        "Responding" => "bg-primary",
                                        "Resolved" => "bg-success",
                                        "Rejected" => "bg-secondary",
                                        default => "bg-dark"
                                    };
                                ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($report["report_code"]) ?></strong>
                                        <?php if ($report["reporter_name"]): ?>
                                            <div class="small text-muted">
                                                <?= htmlspecialchars($report["reporter_name"]) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="../<?= htmlspecialchars($report["image_path"]) ?>"
                                           target="_blank">
                                            <img
                                                src="../<?= htmlspecialchars($report["image_path"]) ?>"
                                                class="report-photo"
                                                alt="Incident photo"
                                            >
                                        </a>
                                    </td>

                                    <td><?= htmlspecialchars($report["incident_type"]) ?></td>

                                    <td style="min-width:220px">
                                        <?= nl2br(htmlspecialchars($report["description"])) ?>
                                    </td>

                                    <td>
                                        <a
                                            target="_blank"
                                            href="https://www.openstreetmap.org/?mlat=<?= urlencode($report["latitude"]) ?>&mlon=<?= urlencode($report["longitude"]) ?>#map=18/<?= urlencode($report["latitude"]) ?>/<?= urlencode($report["longitude"]) ?>"
                                            class="btn btn-sm btn-outline-primary"
                                        >
                                            📍 View Map
                                        </a>
                                        <div class="small text-muted mt-1">
                                            <?= htmlspecialchars($report["latitude"]) ?>,
                                            <?= htmlspecialchars($report["longitude"]) ?>
                                            <?php if ($report["location_accuracy"] !== null): ?>
                                                <br>±<?= round((float)$report["location_accuracy"]) ?>m
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <td>
                                        <span class="badge <?= $badge ?>">
                                            <?= htmlspecialchars($report["status"]) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars(date("M d, Y h:i A", strtotime($report["created_at"]))) ?>
                                    </td>

                                    <td>
                                        <button
                                            class="btn btn-sm btn-primary"
                                            data-bs-toggle="modal"
                                            data-bs-target="#reportModal<?= (int)$report["id"] ?>"
                                        >
                                            Manage
                                        </button>
                                    </td>
                                </tr>

                                <div class="modal fade" id="reportModal<?= (int)$report["id"] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-xl modal-dialog-scrollable">
                                        <div class="modal-content">

                                            <div class="modal-header">
                                                <h5 class="modal-title">
                                                    <?= htmlspecialchars($report["report_code"]) ?>
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>

                                            <div class="modal-body">
                                                <div class="row g-4">

                                                    <div class="col-lg-5">
                                                        <img
                                                            src="../<?= htmlspecialchars($report["image_path"]) ?>"
                                                            class="img-fluid rounded shadow-sm"
                                                            alt="Incident photo"
                                                        >
                                                    </div>

                                                    <div class="col-lg-7">
                                                        <h6 class="fw-bold">Description</h6>
                                                        <p><?= nl2br(htmlspecialchars($report["description"])) ?></p>

                                                        <h6 class="fw-bold">Reporter</h6>
                                                        <p>
                                                            <?= htmlspecialchars($report["reporter_name"] ?: "Anonymous") ?>
                                                            <?php if ($report["reporter_contact"]): ?>
                                                                <br><?= htmlspecialchars($report["reporter_contact"]) ?>
                                                            <?php endif; ?>
                                                        </p>

                                                        <h6 class="fw-bold">GPS</h6>
                                                        <p>
                                                            <?= htmlspecialchars($report["latitude"]) ?>,
                                                            <?= htmlspecialchars($report["longitude"]) ?>
                                                            <?php if ($report["location_accuracy"] !== null): ?>
                                                                <br>Accuracy: ±<?= round((float)$report["location_accuracy"]) ?> meters
                                                            <?php endif; ?>
                                                        </p>

                                                        <a
                                                            target="_blank"
                                                            class="btn btn-outline-primary"
                                                            href="https://www.openstreetmap.org/?mlat=<?= urlencode($report["latitude"]) ?>&mlon=<?= urlencode($report["longitude"]) ?>#map=18/<?= urlencode($report["latitude"]) ?>/<?= urlencode($report["longitude"]) ?>"
                                                        >
                                                            📍 Open Live Map
                                                        </a>
                                                    </div>

                                                </div>

                                                <hr>

                                                <form method="post">
                                                    <input type="hidden" name="id" value="<?= (int)$report["id"] ?>">

                                                    <div class="row">
                                                        <div class="col-md-4 mb-3">
                                                            <label class="form-label fw-semibold">Status</label>
                                                            <select name="status" class="form-select">
                                                                <?php foreach (["Pending","Verified","Responding","Resolved","Rejected"] as $status): ?>
                                                                    <option value="<?= $status ?>"
                                                                        <?= $report["status"] === $status ? "selected" : "" ?>>
                                                                        <?= $status ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>

                                                        <div class="col-md-8 mb-3">
                                                            <label class="form-label fw-semibold">Admin Notes</label>
                                                            <textarea name="admin_notes" class="form-control" rows="3"><?= htmlspecialchars($report["admin_notes"] ?? "") ?></textarea>
                                                        </div>
                                                    </div>

                                                    <button name="update_report" class="btn btn-primary">
                                                        Update Report
                                                    </button>
                                                </form>

                                                <hr>

                                                <?php if (!$report["incident_id"]): ?>
                                                    <form method="post"
                                                          onsubmit="return confirm('Create an official incident from this citizen report?');">
                                                        <input type="hidden" name="id" value="<?= (int)$report["id"] ?>">
                                                        <button name="create_incident" class="btn btn-success">
                                                            ➕ Convert to Official Incident
                                                        </button>
                                                        <div class="small text-muted mt-2">
                                                            This creates a record in your existing <code>incidents</code> table.
                                                        </div>
                                                    </form>
                                                <?php else: ?>
                                                    <div class="alert alert-info mb-0">
                                                        Already converted to official incident
                                                        #<?= (int)$report["incident_id"] ?>.
                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; ?>

                            </tbody>
                        </table>
                    </div>

                    <?php endif; ?>

                </div>
            </div>

        </main>
    </div>
</div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>
</body>
</html>
